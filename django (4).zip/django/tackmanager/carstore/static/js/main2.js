

window.onload = function () {
	const colour_btn_els = document.querySelectorAll('.colours .colour');
	const interior_btn_els = document.querySelectorAll('.interior .colour');
	const capacity_btn_els = document.querySelectorAll('.capacity .size');
	const seating_btn_els = document.querySelectorAll('.seating .layout');
	const imagery_el = document.querySelector('.imagery');
	const image_el = document.querySelector('.imagery .image');
	const imageint_el = document.querySelector('.imagery .interior');


	for (let i = 0; i < capacity_btn_els.length; i++) {
		let btn = capacity_btn_els[i];

		btn.addEventListener('click', function () {
			document.querySelector('.capacity .size.selected').classList.remove('selected');
			this.classList.add('selected');
		});
	}

	for (let i = 0; i < colour_btn_els.length; i++) {
		let btn = colour_btn_els[i];

		btn.addEventListener('click', function () {
			document.querySelector('.colours .colour.selected').classList.remove('selected');
			this.classList.add('selected');
			var imageUrl = 'static/images/x-'+ this.dataset.name+'.jpg';
			document.querySelector('.imagery .image').src=imageUrl
			// image_el.src = "pic2.src = url" + this.dataset.name + 'pic2.src = url2';
			// imagery_el.style.backgroundColor = this.dataset.colour;
		});
	}

	for (let i = 0; i < interior_btn_els.length; i++) {
		let btn = interior_btn_els[i];

		btn.addEventListener('click', function () {
			document.querySelector('.interior .colour.selected').classList.remove('selected');
			this.classList.add('selected');
			var imageUrl2 = 'static/images/interior-'+ this.dataset.name+'.jpg';
			document.querySelector('.imagery .interior	').src=imageUrl2

		});

	}

	for (let i = 0; i < seating_btn_els.length; i++) {
		let btn = seating_btn_els[i];

		btn.addEventListener('click', function () {
			document.querySelector('.seating .layout.selected').classList.remove('selected');
			this.classList.add('selected');
		});
	}



}