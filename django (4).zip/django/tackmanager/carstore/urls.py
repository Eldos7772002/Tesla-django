from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView
from .views import ProductDetailView,RegistrationView,AccountView,LoginView,cars,  BaseView, CategoryDetailView, CartView, AddToCartView, DeleteFromCartView, ChangeQTYView,CheckoutView,MakeOrderView
urlpatterns = [
    path('', views.index, name='index'),


]

urlpatterns += [
    path('cars', views.cars, name='cars'),
    path('car', BaseView.as_view(), name='car'),
    path('products/<str:ct_model>/<str:slug>/', ProductDetailView.as_view(), name='car'),
    path('products/sedan/Model3/', ProductDetailView.as_view(), name='model3'),
    path('products/sedan/ModelY/', ProductDetailView.as_view(), name='modelY'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='/'), name='logout'),
    path('registration/', RegistrationView.as_view(), name='registration'),
    path('account/', AccountView.as_view(), name='account'),
    path('products/liftback/ModelS/', ProductDetailView.as_view(), name='modelS'),
    path('products/suv/ModelX/', ProductDetailView.as_view(), name='modelX'),
    path('category/<str:slug>/', CategoryDetailView.as_view(), name='category_detail'),
    path('category/Suvs/', CategoryDetailView.as_view(), name='ModelX'),
    path('category/Liftbacks/', CategoryDetailView.as_view(), name='ModelS'),
    path('category/Sedans/', CategoryDetailView.as_view(), name='Model3'),
    path('cart/', CartView.as_view(), name='cart'),
    path('add-to-cart/<str:ct_model>/<str:slug>/', AddToCartView.as_view(), name='add_to_cart'),
    path('remove-from-cart/<str:ct_model>/<str:slug>/', DeleteFromCartView.as_view(), name='delete_from_cart'),
    path('change-qty/<str:ct_model>/<str:slug>/', ChangeQTYView.as_view(), name='change_qty'),
    path('checkout/', CheckoutView.as_view(), name='checkout'),
    path('make-order/', MakeOrderView.as_view(), name='make_order')
]
